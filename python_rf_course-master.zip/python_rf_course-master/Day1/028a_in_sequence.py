print("Results")
print("-------")
numbers = [1, 2, 3]
2 in numbers
5 in numbers

# Strings
print("cat" in "cathedral")
print("dog" in "cathedral")

# Dictionaries
menu = {"coffee": 3, "tea": 2}
print("coffee" in menu)
print(3 in menu)

# Reverse Operation
print(4 not in numbers)
