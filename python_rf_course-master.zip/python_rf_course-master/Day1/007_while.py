print("Results")
print("-------")

# Initialize a counter
count = 0

# Set up a while loop that runs as long as count is less than 5
while count < 5:
   print("Count is currently", count, ". It is less than 5.")
   count += 1  # Increment the counter

print("Loop has finished.")