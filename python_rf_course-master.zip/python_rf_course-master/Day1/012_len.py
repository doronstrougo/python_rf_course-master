p1 = [1, 2, 3]
print("len(p1) = ", len(p1))

p2 = []
print("len(p2) = ", len(p2))

p3 = [[1, 2, 3], [4, 5, 6]]
print("len(p3) = ", len(p3))

my_list = [0, 5, [0, -17]]
for i in range(len(my_list)):
    print(my_list[i])