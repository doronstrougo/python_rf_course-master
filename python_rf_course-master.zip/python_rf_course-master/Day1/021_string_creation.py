print("Results")
print("-------")
# Single quotes
single_quoted = 'Hello, World!'
print(single_quoted)
print()

# Double quotes
double_quoted = "Python is great"
print(double_quoted)
print()

# Triple quotes for multi-line strings
multi_line = '''This is a
multi-line
string'''
print(multi_line)

# Triple double quotes
another_multi_line = """
It can also be done
with double quotes
"""
print(another_multi_line)