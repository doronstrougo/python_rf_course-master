print("Results")
print("-------")

regular_string_wrong = "c:\\path\\to\\file"
regular_string_correct = "c:\\\\path\\\\to\\\\file"
print(regular_string_wrong)
print(regular_string_correct)

raw_string = r"c:\path\to\file"
print(raw_string)