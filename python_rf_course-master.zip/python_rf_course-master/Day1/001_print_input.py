print("Results")
print("-------")
print("Hello World")
a = 1
print(a)
b = "Hello"
print(b)
x=input("Please input your name: ")
print("Hello", x, ". Nice to meet you")
