print("Results")
print("-------")
x = 10

if x > 5:
    print("x is greater than 5")
    if x < 8:
        print("x is also less than 15")
    print("x is still greater than 5")
print("This line runs regardless of the value of x")

if x == 10:
    print("x is equal to 10")
print("This line is not part of the if block")