print("Results")
print("-------")
print(20 // 3)
print(-20 // 3)  # Note the behavior with negative numbers
print()

print("% (Modulo):")
print(20 % 3)
print(-20 % 3)  # Note the behavior with negative numbers
print()

print("/ Normal Division")
print(20 / 3)