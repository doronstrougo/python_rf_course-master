print("Results")
print("-------")

x = 5.0
y = 5.5
print(x.is_integer())
print(y.is_integer())

z = 3.25
print(z.as_integer_ratio())

x = 3.14159
print(round(x, 2))

y = -4.5
print(abs(y))

import math

z = 5.1
print(math.ceil(z))

z = -6.1
print(math.ceil(z))

a = 5.9
print(math.floor(a))

a = -17.3
print(math.floor(a))

b = 3.7
print(math.trunc(b))

b = -4.3
print(math.trunc(b))